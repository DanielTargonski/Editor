#pragma once

template<typename TYPE>
int binarySearch(TYPE anArray[], int first, int last, TYPE target);